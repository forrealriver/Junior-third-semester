/**
  * Created by hadoop on 17-5-24.
  * Change on 17-8-29
  */
import org.apache.spark.SparkConf
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.client.{ConnectionFactory, Put}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.client._
import org.apache.spark.SparkContext
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, SQLContext}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.mllib.linalg.{Vector, Vectors}
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.api.java.JavaRDD
import scala.collection.mutable.ArrayBuffer
import HBase_Con._
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import java.util.{Date, Locale}
import java.text.SimpleDateFormat
import java.lang.NumberFormatException
import org.apache.spark.ml.clustering.KMeans
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StructType,StructField,StringType}
import org.apache.spark.sql.SparkSession
import java.io.FileWriter
import Position._
object wenjia1 {
  def main(args: Array[String]) {
    Logger.getLogger("org.apache.spark").setLevel(Level.ERROR)
    Logger.getLogger("org.eclipse.jetty.server").setLevel(Level.OFF)
    val sparkConf = new SparkConf().setAppName("sji").setMaster("local[2]")
    sparkConf.set("spark.testing.memory", "2147480000")
    val sc = new SparkContext(sparkConf)
    val sqcX=new SQLContext(sc)
    val config = HBaseConfiguration.create()
    val conn = ConnectionFactory.createConnection(config)

    def Hbase_count(name: String): Long = {
      config.set(TableInputFormat.INPUT_TABLE, name)
      val stuRDD = sc.newAPIHadoopRDD(config, classOf[TableInputFormat],
        classOf[org.apache.hadoop.hbase.io.ImmutableBytesWritable],
        classOf[org.apache.hadoop.hbase.client.Result])
      val count = stuRDD.count()
      count
    }


//    Hbase_truncate(conn,"00aabbcc")
//    Hbase_truncate(conn,"temp_log")
//    Hbase_truncate(conn,"store_temp")
//    Hbase_truncate(conn,"store_log")
//    Hbase_truncate(conn,"store_time")
//    Hbase_truncate(conn,"human_times")
//    Hbase_truncate(conn,"human_history")
//    Hbase_truncate(conn,"new_old_history")
//    Hbase_truncate(conn,"count_human_times")
//    Hbase_truncate(conn,"shop_times")
//    Hbase_truncate(conn,"interview_times")
//    Hbase_truncate(conn,"jump_log")
//    Hbase_truncate(conn,"deep_log")
//    Hbase_truncate(conn,"activity_log")


    //品牌api
    val ta=sc.textFile("/home/hadoop/Documents/mac_phone_api.txt")
    val num=ta.count()
    val list=ta.take(num.toInt)

    //变量定义
    var A: ArrayBuffer[People] = null
    var dianpu_name: ArrayBuffer[String] = null
    //次数define
    val x_num: Array[Int] = new Array[Int](6)
    val t_num: Array[Int] = new Array[Int](7)
    val h_num: Array[Int] = new Array[Int](7)
    var new_people: Long = 0
    var old_people: Long = 0
    var last_hour = new String
    var last_day: Int = 24
    var last_week: Int = 24 * 7
    var last_month: Int = 24 * 30
    var ke_hour: Long = 0
    var ke_day: Long = 0
    var ke_week: Long = 0
    var ke_month: Long = 0
    var ru_hour: Long = 0
    var ru_day: Long = 0
    var ru_week: Long = 0
    var ru_month: Long = 0
    var zq1_hour: Long = 0
    var zq1_day: Long = 0
    var zq1_week: Long = 0
    var zq1_month: Long = 0
    var zq2_hour: Long = 0
    var zq2_day: Long = 0
    var zq2_week: Long = 0
    var zq2_month: Long = 0
    var zq3_hour: Long = 0
    var zq3_day: Long = 0
    var zq3_week: Long = 0
    var zq3_month: Long = 0
    var zq4_hour: Long = 0
    var zq4_day: Long = 0
    var zq4_week: Long = 0
    var zq4_month: Long = 0
    var zq5_hour: Long = 0
    var zq5_day: Long = 0
    var zq5_week: Long = 0
    var zq5_month: Long = 0
    var rur_hour: Double = 0
    var rur_day: Double = 0
    var rur_week: Double = 0
    var rur_month: Double = 0
    var new_hour: Long = 0
    var new_day: Long = 0
    var new_week: Long = 0
    var new_month: Long = 0
    var old_hour: Long = 0
    var old_day: Long = 0
    var old_week: Long = 0
    var old_month: Long = 0
    var zd1_hour: Long = 0
    var zd1_day: Long = 0
    var zd1_week: Long = 0
    var zd1_month: Long = 0
    var zd2_hour: Long = 0
    var zd2_day: Long = 0
    var zd2_week: Long = 0
    var zd2_month: Long = 0
    var zd3_hour: Long = 0
    var zd3_day: Long = 0
    var zd3_week: Long = 0
    var zd3_month: Long = 0
    var zd4_hour: Long = 0
    var zd4_day: Long = 0
    var zd4_week: Long = 0
    var zd4_month: Long = 0
    var blank_people: Long = 0
    val df = new SimpleDateFormat("EEE MMM dd HH:mm:ss yyyy", Locale.ENGLISH)
    val df2 = new SimpleDateFormat("HH", Locale.ENGLISH)
    val df_day = new SimpleDateFormat("dd", Locale.ENGLISH)
    val df_week = new SimpleDateFormat("EEE", Locale.ENGLISH)
    val df_month = new SimpleDateFormat("MM", Locale.ENGLISH)
    val df_dianpu_h=new SimpleDateFormat("yyy-MM-dd")
    var ttime=df.format(new Date())

    def xxx10(tablename: String, key: String, values: String,dianpu: String): Unit = {
      var hx = Hbase_get(conn, tablename, dianpu, key, "9")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "10", hx)
      }
      hx = Hbase_get(conn, tablename, dianpu, key, "8")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "9", hx)
      }
      hx = Hbase_get(conn, tablename, dianpu, key, "7")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "8", hx)
      }
      hx = Hbase_get(conn, tablename, dianpu, key, "6")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "7", hx)
      }
      hx = Hbase_get(conn, tablename, dianpu, key, "5")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "6", hx)
      }
      hx = Hbase_get(conn, tablename, dianpu, key, "4")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "5", hx)
      }
      hx = Hbase_get(conn, tablename, dianpu, key, "3")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "4", hx)
      }
      hx = Hbase_get(conn, tablename, dianpu, key, "2")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "3", hx)
      }
      hx = Hbase_get(conn, tablename, dianpu, key, "1")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "2", hx)
      }
      Hbase_insert(conn, tablename, dianpu, key, "1", values)
    }
    def xxx(tablename: String, key: String, values: String,dianpu: String): Unit = {
      var hx = Hbase_get(conn, tablename, dianpu, key, "5")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "6", hx)
      }
      hx = Hbase_get(conn, tablename, dianpu, key, "4")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "5", hx)
      }
      hx = Hbase_get(conn, tablename, dianpu, key, "3")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "4", hx)
      }
      hx = Hbase_get(conn, tablename, dianpu, key, "2")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "3", hx)
      }
      hx = Hbase_get(conn, tablename, dianpu, key, "1")
      if (hx != null) {
        Hbase_insert(conn, tablename, dianpu, key, "2", hx)
      }
      Hbase_insert(conn, tablename, dianpu, key, "1", values)
    }
    var ix:Int=1
    var current_dianpu=new String
    while(ix!=0) {
      ix -= 1
      val time1 = df.format(new Date())
      //获取店铺名称、遍历
      dianpu_name=Hbase_scan_dianpu(conn,"dianpu")
      var dianpu_num=dianpu_name.length
      while(dianpu_num !=0 ) {
        current_dianpu = dianpu_name(dianpu_num - 1)
        dianpu_num -= 1
        if (current_dianpu.indexOf("blank_") == -1) {
          val current_tanz1_name = Hbase_get(conn, "dianpu", current_dianpu, "WifiId", "1")
          val current_tanz1_x = Hbase_get(conn, "dianpu", current_dianpu, "WifiId", "x1")
          val current_tanz1_y = Hbase_get(conn, "dianpu", current_dianpu, "WifiId", "y1")
          val current_tanz2_name = Hbase_get(conn, "dianpu", current_dianpu, "WifiId", "2")
          val current_tanz2_x = Hbase_get(conn, "dianpu", current_dianpu, "WifiId", "x2")
          val current_tanz2_y = Hbase_get(conn, "dianpu", current_dianpu, "WifiId", "y2")
          val current_tanz3_name = Hbase_get(conn, "dianpu", current_dianpu, "WifiId", "3")
          val current_tanz3_x = Hbase_get(conn, "dianpu", current_dianpu, "WifiId", "x3")
          val current_tanz3_y = Hbase_get(conn, "dianpu", current_dianpu, "WifiId", "y3")
          val dianpu_right_down_x = Hbase_get(conn, "dianpu", current_dianpu, "fanwei", "right_down_x")
          val dianpu_right_down_y = Hbase_get(conn, "dianpu", current_dianpu, "fanwei", "right_down_y")
          val dianpu_left_up_x = Hbase_get(conn, "dianpu", current_dianpu, "fanwei", "dianpu_left_up_x")
          val dianpu_left_up_y = Hbase_get(conn, "dianpu", current_dianpu, "fanwei", "dianpu_left_up_y")

          var num_mac = 0
          if (current_tanz1_name != null && current_tanz2_name != null && current_tanz3_name != null
            && current_tanz1_x != null && current_tanz1_y != null && current_tanz2_x != null &&
            current_tanz2_y != null && current_tanz3_x != null && current_tanz3_y != null &&
            dianpu_right_down_x != null && dianpu_right_down_y != null && dianpu_left_up_x != null && dianpu_left_up_y != null
          ) {
            val dianpu_right_down: xy = null
            val dianpu_left_up: xy = null
            dianpu_right_down.x = dianpu_right_down_x.toDouble
            dianpu_right_down.y = dianpu_right_down_y.toDouble
            dianpu_left_up.x = dianpu_left_up_x.toDouble
            dianpu_left_up.y = dianpu_left_up_y.toDouble

            x_num(0) = 0
            x_num(1) = 0
            x_num(2) = 0
            x_num(3) = 0
            x_num(4) = 0
            x_num(5) = 0
            t_num(0) = 0
            t_num(1) = 0
            t_num(2) = 0
            t_num(3) = 0
            t_num(4) = 0
            h_num(0) = 0
            h_num(1) = 0
            h_num(2) = 0
            h_num(3) = 0
            //遍历temp
            A = Hbase_scan2(conn, current_tanz1_name)
            val c = A.toArray
            val count_all = A.length
            var count_in: Long = 0
            if (c.nonEmpty) {
              //插入客流量日志
              Hbase_insert(conn, "temp_log", A(0).time, "count", current_dianpu, count_all.toString)
              xxx10("keliu", "now", count_all.toString, current_dianpu)
              //判断是进店铺还是出店铺
              if (c.length != 0) {
                var i = c.length
                while (i != 0) {
                  i -= 1
                  val human_in = Hbase_get(conn, "store_temp", A(i).mac, "time", current_dianpu)
                  var in_or_out: Int = 0
                  if (A(i).range != null) {
                    val wifi2 = Hbase_get(conn, current_tanz2_name, A(i).mac, "range", "1")
                    val wifi3 = Hbase_get(conn, current_tanz3_name, A(i).mac, "range", "1")
                    //                  一点
                    //                if (A(i).range.toInt < 100)
                    //                  in_or_out=1
                    //                else in_or_out=2

                    var weizhi: xy = null
                    //三点
                    if (wifi2 != null && wifi3 != null) {
                      val d1 = A(i).range.toInt
                      val d2 = wifi2.toInt
                      val d3 = wifi3.toInt
                      weizhi = position(current_tanz1_x.toDouble, current_tanz1_y.toDouble, current_tanz2_x.toDouble, current_tanz2_y.toDouble,
                        current_tanz3_x.toDouble, current_tanz3_y.toDouble, d1, d2, d3, 0.3)
                      if (dianpu_right_down.x < dianpu_left_up.x) {
                        val jj = dianpu_right_down.x
                        dianpu_right_down.x = dianpu_left_up.x
                        dianpu_left_up.x = jj
                      }
                      if (dianpu_right_down.y > dianpu_left_up.y) {
                        val jj = dianpu_right_down.y
                        dianpu_right_down.y = dianpu_left_up.y
                        dianpu_left_up.y = jj
                      }

                      if (weizhi.x >= dianpu_left_up.x && weizhi.x <= dianpu_right_down.x &&
                        weizhi.y >= dianpu_right_down.y && weizhi.y <= dianpu_left_up.y
                      ) {
                        num_mac += 1
                        in_or_out = 1
                        Hbase_insert(conn, "position", current_dianpu, "x", num_mac.toString, (weizhi.x - dianpu_left_up.x).toString)
                        Hbase_insert(conn, "position", current_dianpu, "y", num_mac.toString, (weizhi.y - dianpu_right_down.y).toString)
                      }
                      else in_or_out = 2
                    }

                    if (in_or_out == 1) {
                      count_in += 1
                      //进入店铺的人，判断是否是刚进来的
                      if (human_in == null) {
                        Hbase_insert(conn, "store_temp", A(i).mac, "time", current_dianpu, A(i).time)
                        //判断新老顾客，记录访问次数和时间
                        val values = Hbase_get(conn, "human_times", A(i).mac, "values", current_dianpu)
                        if (values == null) {
                          x_num(0) += 1
                          Hbase_insert(conn, "human_times", A(i).mac, "time", current_dianpu, A(i).time)
                          Hbase_insert(conn, "human_times", A(i).mac, "values", current_dianpu, "1")
                          Hbase_insert(conn, "human_history", A(i).mac, "this_time", current_dianpu, A(i).time)
                        }
                        else {
                          var x = values.toInt
                          x += 1
                          Hbase_insert(conn, "human_times", A(i).mac, "time", current_dianpu, A(i).time)
                          Hbase_insert(conn, "human_times", A(i).mac, "values", current_dianpu, x.toString)
                          //来访次数
                          if (x == 2) x_num(1) += 1
                          else if (x == 3) x_num(2) += 1
                          else if (x == 4) x_num(3) += 1
                          else if (x == 5) x_num(4) += 1
                          else x_num(5) += 1

                          val human_last_time = Hbase_get(conn, "human_history", A(i).mac, "this_time", current_dianpu)
                          Hbase_insert(conn, "human_history", A(i).mac, "last_time", current_dianpu, human_last_time)
                          Hbase_insert(conn, "human_history", A(i).mac, "this_time", current_dianpu, A(i).time)
                          val n = Times.Time_Duration_Minutes(A(i).time, human_last_time)
                          Hbase_insert(conn, "human_history", A(i).mac, "subtract", current_dianpu, n.toString)
                          //来访周期
                          if (n >= 0 && n < 1) t_num(0) += 1
                          else if (n < 2 && n >= 1) t_num(1) += 1
                          else if (n < 3 && n >= 2) t_num(2) += 1
                          else if (n < 4 && n >= 3) t_num(3) += 1
                          else t_num(4) += 1
                        }
                        Hbase_insert(conn, "store_time", A(i).mac, "intime", current_dianpu, A(i).time)
                        Hbase_insert(conn, "store_time", A(i).mac, "subtract", current_dianpu, "1")

                        //品牌
                        val macc = A(i).mac.split(":")
                        val maccc = macc(0) + "-" + macc(1) + "-" + macc(2)
                        var pingpai: String = null
                        for (i <- list) {
                          val m = i.indexOf(maccc.toUpperCase)
                          if (m != -1)
                            pingpai = i
                        }
                        if (pingpai != null) {
                          val pinpai = pingpai.toLowerCase
                          if (pinpai.indexOf("apple") != -1)
                            printf("Apple")
                          else if (pinpai.indexOf("huawei") != -1)
                            printf("Huawei")
                          else if (pinpai.indexOf("microsoft") != -1)
                            printf("Microsoft")
                          else if (pinpai.indexOf("htc") != -1)
                            printf("HTC")
                          else if (pinpai.indexOf("tcl") != -1)
                            printf("TCL")
                          else if (pinpai.indexOf("google") != -1)
                            printf("Google")
                          else if (pinpai.indexOf("qiku") != -1)
                            printf("360")
                          else if (pinpai.indexOf("qiku") != -1)
                            printf("360Qiku")
                          else if (pinpai.indexOf("zte") != -1)
                            printf("zhongxing")
                          else if (pinpai.indexOf("lg") != -1)
                            printf("LG")
                          else if (pinpai.indexOf("sony") != -1)
                            printf("Sony")
                          else if (pinpai.indexOf("nokia") != -1)
                            printf("nokia")
                          else if (pinpai.indexOf("xiaomi") != -1)
                            printf("xiaomi")
                          else if (pinpai.indexOf("lenovo") != -1)
                            printf("Lenovo")
                          else if (pinpai.indexOf("samsung") != -1)
                            printf("SAMSUNG")
                          else if (pinpai.indexOf("wingtech") != -1 || pinpai.indexOf("meizu") != -1)
                            printf("meizu")
                          else if (pinpai.indexOf("oppo") != -1)
                            printf("OPPO")
                          else if (pinpai.indexOf("vivo") != -1)
                            printf("vivo")
                        }
                        else printf("other")

                      }
                      else {
                        var xskj = Hbase_get(conn, "human_times", A(i).mac, "values", current_dianpu)

                        if (xskj == null) {
                          xskj = "1"
                        }
                        val x = xskj.toInt
                        if (x == 1) x_num(0) += 1
                        else if (x == 2) x_num(1) += 1
                        else if (x == 3) x_num(2) += 1
                        else if (x == 4) x_num(3) += 1
                        else if (x == 5) x_num(4) += 1
                        else x_num(5) += 1

                        var xml = Hbase_get(conn, "human_history", A(i).mac, "subtract", current_dianpu)
                        if (xml == null) {
                          xml = "0"
                        }
                        val n = xml.toInt
                        if (n >= 0 && n < 1) t_num(0) += 1
                        else if (n < 2 && n >= 1) t_num(1) += 1
                        else if (n < 3 && n >= 2) t_num(2) += 1
                        else if (n < 4 && n >= 3) t_num(3) += 1
                        else t_num(4) += 1

                        var wz = Hbase_get(conn, "store_time", A(i).mac, "subtract", current_dianpu)
                        var wzj = Hbase_get(conn, "store_time", A(i).mac, "intime", current_dianpu)
                        if (wzj == null) {
                          wzj = A(i).time
                        }
                        if (wz == null) {
                          wz = "1"
                        }
                        val xpx = wz.toInt
                        val num = Times.Time_Duration_Seconds(A(i).time, wzj)
                        val xpxx = xpx + num.toInt
                        Hbase_insert(conn, "store_time", A(i).mac, "subtract", current_dianpu, xpxx.toString)
                        Hbase_insert(conn, "store_time", A(i).mac, "intime", current_dianpu, A(i).time)
                        //顾客活跃度
                        if (xpx <= 1 * 30 && xpx >= 0) h_num(0) += 1
                        else if (xpx > 1 * 30 && xpx <= 1 * 60) h_num(1) += 1
                        else if (xpx > 1 * 60 && xpx <= 5 * 60) h_num(2) += 1
                        else h_num(3) += 1
                      }
                    }
                    else if (in_or_out == 2) {
                      //在店铺外的人，判断是否是刚出去的
                      if (human_in != null) {
                        Hbase_deleteOne(conn, "store_temp", A(i).mac, "time", current_dianpu)
                        Hbase_insert(conn, "store_time", A(i).mac, "outtime", current_dianpu, A(i).time)
                      }
                    }
                  }
                }
              }
              Hbase_insert(conn, "position", current_dianpu, "values", "1", num_mac.toString)
              //顾客访问次数历史
              Hbase_insert(conn, "count_human_times", A(0).time, "1", current_dianpu, x_num(0).toString)
              Hbase_insert(conn, "count_human_times", A(0).time, "2", current_dianpu, x_num(1).toString)
              Hbase_insert(conn, "count_human_times", A(0).time, "3", current_dianpu, x_num(2).toString)
              Hbase_insert(conn, "count_human_times", A(0).time, "4", current_dianpu, x_num(3).toString)
              Hbase_insert(conn, "count_human_times", A(0).time, "5", current_dianpu, x_num(4).toString)
              Hbase_insert(conn, "count_human_times", A(0).time, "other", current_dianpu, x_num(5).toString)

              //顾客驻店时间历史
              Hbase_insert(conn, "shop_times", A(0).time, "1", current_dianpu, h_num(0).toString)
              Hbase_insert(conn, "shop_times", A(0).time, "5", current_dianpu, h_num(1).toString)
              Hbase_insert(conn, "shop_times", A(0).time, "10", current_dianpu, h_num(2).toString)
              Hbase_insert(conn, "shop_times", A(0).time, "15", current_dianpu, h_num(3).toString)
              Hbase_insert(conn, "shop_times", A(0).time, "30", current_dianpu, h_num(4).toString)
              Hbase_insert(conn, "shop_times", A(0).time, "60", current_dianpu, h_num(5).toString)
              Hbase_insert(conn, "shop_times", A(0).time, "other", current_dianpu, h_num(6).toString)

              //顾客访问周期历史
              Hbase_insert(conn, "interview_times", A(0).time, "12", current_dianpu, t_num(0).toString)
              Hbase_insert(conn, "interview_times", A(0).time, "24", current_dianpu, t_num(1).toString)
              Hbase_insert(conn, "interview_times", A(0).time, "36", current_dianpu, t_num(2).toString)
              Hbase_insert(conn, "interview_times", A(0).time, "48", current_dianpu, t_num(3).toString)
              Hbase_insert(conn, "interview_times", A(0).time, "60", current_dianpu, t_num(4).toString)

              //驻点时长 now 记录
              Hbase_insert(conn, "zhudian1", current_dianpu, "now", "1", h_num(0).toString)
              Hbase_insert(conn, "zhudian2", current_dianpu, "now", "1", h_num(1).toString)
              Hbase_insert(conn, "zhudian3", current_dianpu, "now", "1", h_num(2).toString)
              Hbase_insert(conn, "zhudian4", current_dianpu, "now", "1", h_num(3).toString)
              //访问周期 now 记录
              Hbase_insert(conn, "zhouqi1", current_dianpu, "now", "1", t_num(0).toString)
              Hbase_insert(conn, "zhouqi2", current_dianpu, "now", "1", t_num(1).toString)
              Hbase_insert(conn, "zhouqi3", current_dianpu, "now", "1", t_num(2).toString)
              Hbase_insert(conn, "zhouqi4", current_dianpu, "now", "1", t_num(3).toString)
              Hbase_insert(conn, "zhouqi5", current_dianpu, "now", "1", t_num(4).toString)

              //计算入店量和入店率
              Hbase_insert(conn, "store_log", A(0).time, "count", current_dianpu, count_in.toString)
              xxx10("rudian", "now", count_in.toString, current_dianpu)
              Hbase_insert(conn, "store_log", A(0).time, "rate", current_dianpu, (count_in.toDouble / count_all.toDouble).toString)
              xxx10("rudr", "now", (count_in.toDouble / count_all.toDouble).toString, current_dianpu)

              Hbase_insert(conn, "zhouqi1", current_dianpu, "rate", "1", (t_num(0).toDouble / count_in.toDouble).toString)
              Hbase_insert(conn, "zhouqi2", current_dianpu, "rate", "1", (t_num(1).toDouble / count_in.toDouble).toString)
              Hbase_insert(conn, "zhouqi3", current_dianpu, "rate", "1", (t_num(2).toDouble / count_in.toDouble).toString)
              Hbase_insert(conn, "zhouqi4", current_dianpu, "rate", "1", (t_num(3).toDouble / count_in.toDouble).toString)
              Hbase_insert(conn, "zhouqi5", current_dianpu, "rate", "1", (t_num(4).toDouble / count_in.toDouble).toString)

              Hbase_insert(conn, "new_old_history", A(0).time, "new", current_dianpu, x_num(0).toString)
              Hbase_insert(conn, "new_old_history", A(0).time, "old", current_dianpu, (count_in - x_num(0)).toString)
              Hbase_insert(conn, "new_old_history", A(0).time, "rate", current_dianpu, (x_num(0).toDouble / (count_in - x_num(0)).toDouble).toString)
              Hbase_insert(conn, "new_old", current_dianpu, "new", "1", x_num(0).toString)
              Hbase_insert(conn, "new_old", current_dianpu, "old", "1", (count_in - x_num(0)).toString)

              Hbase_insert(conn, "jump_log", A(0).time, "jump_human", current_dianpu, h_num(0).toString)
              Hbase_insert(conn, "jump_log", A(0).time, "all_human", current_dianpu, count_all.toString)
              Hbase_insert(conn, "jump_log", A(0).time, "rate", current_dianpu, (h_num(0).toDouble / count_all.toDouble).toString)

              Hbase_insert(conn, "deep_log", A(0).time, "num", current_dianpu, (h_num(5) + h_num(6)).toString)
              Hbase_insert(conn, "deep_log", A(0).time, "all", current_dianpu, count_all.toString)
              Hbase_insert(conn, "deep_log", A(0).time, "rate", current_dianpu, ((h_num(5) + h_num(6)).toDouble / count_all.toDouble).toString)

              Hbase_insert(conn, "activity_log", A(0).time, "high", current_dianpu, (t_num(0) + t_num(1)).toString)
              Hbase_insert(conn, "activity_log", A(0).time, "medium", current_dianpu, (t_num(2) + t_num(3)).toString)
              Hbase_insert(conn, "activity_log", A(0).time, "low", current_dianpu, (t_num(4) + t_num(5)).toString)
              Hbase_insert(conn, "activity_log", A(0).time, "sleep", current_dianpu, t_num(6).toString)

              val chushihua=Hbase_get(conn,"time_jilu",current_dianpu,"chushihua","1")


              if (chushihua ==null) {
                Hbase_insert(conn,"time_jilu",current_dianpu,"chushihua","1","1")
                Hbase_insert(conn,"time_jilu",current_dianpu,"last_hour","1",df.format(new Date()))
                Hbase_insert(conn,"time_jilu",current_dianpu,"last_day","1","24")
                Hbase_insert(conn,"time_jilu",current_dianpu,"last_week","1","168")
                Hbase_insert(conn,"time_jilu",current_dianpu,"last_month","1","720")
              }
              last_hour = Hbase_get(conn,"time_jilu",current_dianpu,"last_hour","1")

              val new_time=df.format(new Date())

              //记录历史(前一小时、一天、一周、一月）\环比（时、天、周、月）
              if (Times.Time_Duration_Minutes(new_time, last_hour) >= 60) {
                Hbase_insert(conn,"time_jilu",current_dianpu,"last_hour","1",new_time)
                val HH = df2.format(new Date())
                val EEE = df_week.format(new Date())
                val MMM = df_month.format(new Date())
                val DDD = df_day.format(new Date())
                var eee: Int = 0
                EEE match {
                  case "Mon" => eee = 1
                  case "Tues" => eee = 2
                  case "Wed" => eee = 3
                  case "Thur" => eee = 4
                  case "Fri" => eee = 5
                  case "Sat" => eee = 6
                  case "Sun" => eee = 7
                }
                var kww: Int = 0
                if (eee == 7)
                  kww = 1
                else kww = eee + 1 //当前周

                var khh: Int = 0
                if (HH.toInt == 23)
                  khh = 0
                else khh = HH.toInt + 1 //当前时

                var kmm: Int = 0
                if (MMM.toInt == 12)
                  kmm = 1
                else kmm = MMM.toInt + 1 //当前月

                var kdd: Int = 0
                if (DDD.toInt == 30)
                  kdd = 1
                else kdd = DDD.toInt + 1 //当前日

                //客流、入店小时预测
                val out_fli1 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_keliu_hour", true)
                out_fli1.write(HH + "," + ke_hour.toString + "\n")
                out_fli1.close()
                val raw_data = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_keliu_hour")
                val map_data = raw_data.map { x =>
                  val split_list = x.split(",")
                  (split_list(0).toInt, split_list(1).toInt)
                }

                var redict_re_double: Double = 0
                if (map_data.count() >= 24) {
                  val dfx = sqcX.createDataFrame(map_data)
                  val datax = dfx.toDF("hour", "keliu")
                  val colArray = Array("hour")
                  val assembler = new VectorAssembler().setInputCols(colArray).setOutputCol("features")
                  val vecDF: DataFrame = assembler.transform(datax)
                  val out_fli2 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_keliu_hour_pr")
                  out_fli2.write(khh.toString + ",0\n")
                  out_fli2.close()
                  val raw_data_predict = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_keliu_hour_pr")
                  val map_data_for_predict = raw_data_predict.map { x =>
                    val split_list = x.split(",")
                    (split_list(0).toInt, split_list(1).toInt)
                  }
                  val df_for_predict = sqcX.createDataFrame(map_data_for_predict)
                  val data_for_predict = df_for_predict.toDF("hour", "keliu")
                  val colArray_for_predict = Array("hour")
                  val assembler_for_predict = new VectorAssembler().setInputCols(colArray_for_predict).setOutputCol("features")
                  val vecDF_for_predict: DataFrame = assembler_for_predict.transform(data_for_predict)
                  // 建立模型，预测keliu
                  // 设置线性回归参数
                  val lr13 = new LinearRegression()
                  val lr2 = lr13.setFeaturesCol("features").setLabelCol("keliu").setFitIntercept(true)
                  // RegParam：正则化
                  val lr3 = lr2.setMaxIter(10).setRegParam(0.3).setElasticNetParam(0.8)
                  val lr = lr3
                  // 将训练集合代入模型进行训练
                  val lrModel = lr.fit(vecDF)
                  // 输出模型全部参数
                  lrModel.extractParamMap()
                  val predictions: DataFrame = lrModel.transform(vecDF_for_predict)
                  //println("输出预测结果")
                  val predict_result: DataFrame = predictions.selectExpr("prediction")
                  val listRow = predict_result.rdd.collect()
                  val ms = listRow(0).toString()
                  val redict_re = ms.slice(1, ms.length - 1)
                  //println(redict_re.toDouble.toInt)
                  redict_re_double = redict_re.toDouble
                  Hbase_insert(conn, "keliu_pr", current_dianpu, "hour", "1", redict_re.toDouble.toInt.toString)
                }

                val out_fli11 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_rudian_hour", true)
                out_fli11.write(HH + "," + ru_hour.toString + "\n")
                out_fli11.close()
                val raw_data1 = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_rudian_hour")
                val map_data1 = raw_data1.map { x =>
                  val split_list = x.split(",")
                  (split_list(0).toInt, split_list(1).toInt)
                }
                if (map_data1.count() >= 24) {
                  val dfx1 = sqcX.createDataFrame(map_data1)
                  val datax1 = dfx1.toDF("hour", "rudian")
                  val colArray1 = Array("hour")
                  val assembler1 = new VectorAssembler().setInputCols(colArray1).setOutputCol("features")
                  val vecDF1: DataFrame = assembler1.transform(datax1)
                  val out_fli21 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_rudian_hour_pr")
                  out_fli21.write(khh.toString + ",0\n")
                  out_fli21.close()
                  val raw_data_predict1 = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_rudian_hour_pr")
                  val map_data_for_predict1 = raw_data_predict1.map { x =>
                    val split_list = x.split(",")
                    (split_list(0).toInt, split_list(1).toInt)
                  }
                  val df_for_predict1 = sqcX.createDataFrame(map_data_for_predict1)
                  val data_for_predict1 = df_for_predict1.toDF("hour", "rudian")
                  val colArray_for_predict1 = Array("hour")
                  val assembler_for_predict1 = new VectorAssembler().setInputCols(colArray_for_predict1).setOutputCol("features")
                  val vecDF_for_predict1: DataFrame = assembler_for_predict1.transform(data_for_predict1)
                  // 建立模型，预测keliu
                  // 设置线性回归参数
                  val lr11 = new LinearRegression()
                  val lr21 = lr11.setFeaturesCol("features").setLabelCol("rudian").setFitIntercept(true)
                  // RegParam：正则化
                  val lr31 = lr21.setMaxIter(10).setRegParam(0.3).setElasticNetParam(0.8)
                  val lr1 = lr31
                  // 将训练集合代入模型进行训练
                  val lrModel1 = lr1.fit(vecDF1)
                  // 输出模型全部参数
                  lrModel1.extractParamMap()
                  val predictions1: DataFrame = lrModel1.transform(vecDF_for_predict1)
                  //println("输出预测结果")
                  val predict_result1: DataFrame = predictions1.selectExpr("prediction")
                  val listRow1 = predict_result1.rdd.collect()
                  val ms1 = listRow1(0).toString()
                  val redict_re1 = ms1.slice(1, ms1.length - 1)
                  //println(redict_re.toDouble.toInt)
                  Hbase_insert(conn, "rudian_pr", current_dianpu, "hour", "1", redict_re1.toDouble.toInt.toString)
                  Hbase_insert(conn, "rudr_pr", current_dianpu, "hour", "1", ((redict_re_double.toInt.toDouble - redict_re1.toDouble.toInt.toDouble) / redict_re_double.toInt.toDouble).toString)
                }

                //一天的环形图
                Hbase_insert(conn, "day_keliu", current_dianpu, "hour", HH, ke_hour.toString)

                //时客流量、环比、3次历史
                var hx = Hbase_get(conn, "keliu", current_dianpu, "hour", "2")
                if (hx != null) {
                  Hbase_insert(conn, "keliu", current_dianpu, "hour", "3", hx)
                }
                var hx2 = Hbase_get(conn, "keliu", current_dianpu, "hour", "1")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (ke_hour - hx2.toInt).toDouble / hx2.toDouble
                  Hbase_insert(conn, "keliu", current_dianpu, "h_hour", "1", x.toString)
                  Hbase_insert(conn, "keliu", current_dianpu, "hour", "2", hx2)
                }
                Hbase_insert(conn, "keliu", current_dianpu, "hour", "1", ke_hour.toString)

                //时入店量、环比、3次历史
                hx = Hbase_get(conn, "rudian", current_dianpu, "hour", "2")
                if (hx != null) {
                  Hbase_insert(conn, "rudian", current_dianpu, "hour", "3", hx)
                }
                hx2 = Hbase_get(conn, "rudian", current_dianpu, "hour", "1")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (ru_hour - hx2.toInt).toDouble / hx2.toDouble
                  Hbase_insert(conn, "rudian", current_dianpu, "h_hour", "1", x.toString)
                  Hbase_insert(conn, "rudian", current_dianpu, "hour", "2", hx2)
                }
                Hbase_insert(conn, "rudian", current_dianpu, "hour", "1", ru_hour.toString)

                //时入店率、环比、3次历史
                rur_hour = ru_hour.toDouble / ke_hour.toDouble
                hx = Hbase_get(conn, "rudr", current_dianpu, "hour", "2")
                if (hx != null) {
                  Hbase_insert(conn, "rudr", current_dianpu, "hour", "3", hx)
                }
                hx2 = Hbase_get(conn, "rudr", current_dianpu, "hour", "1")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (rur_hour - hx2.toDouble) / hx2.toDouble
                  Hbase_insert(conn, "rudr", current_dianpu, "h_hour", "1", x.toString)
                  Hbase_insert(conn, "rudr", current_dianpu, "hour", "2", hx2)
                }
                Hbase_insert(conn, "rudr", current_dianpu, "hour", "1", rur_hour.toString)

                //新顾客所占比例、环比
                var xms = new_hour.toDouble / (old_hour + new_hour).toDouble
                hx2 = Hbase_get(conn, "new_old", current_dianpu, "h_hour", "2")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (xms - hx2.toDouble) / hx2.toDouble
                  Hbase_insert(conn, "new_old", current_dianpu, "h_hour", "1", x.toString)
                }
                Hbase_insert(conn, "new_old", current_dianpu, "h_hour", "2", xms.toString)
                xxx("new_old", "hour", xms.toString, current_dianpu)

                //来访周期记录
                xxx("zhouqi1", "hour", zq1_hour.toString, current_dianpu)
                xxx("zhouqi2", "hour", zq2_hour.toString, current_dianpu)
                xxx("zhouqi3", "hour", zq3_hour.toString, current_dianpu)
                xxx("zhouqi4", "hour", zq4_hour.toString, current_dianpu)
                xxx("zhouqi5", "hour", zq5_hour.toString, current_dianpu)
                //来访周期环比
                hx2 = Hbase_get(conn, "zhouqi1", current_dianpu, "h_hour", "2")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (zq1_hour - hx2.toInt).toDouble / hx2.toDouble
                  Hbase_insert(conn, "zhouqi1", current_dianpu, "h_hour", "1", x.toString)
                }
                Hbase_insert(conn, "zhouqi1", current_dianpu, "h_hour", "2", zq1_hour.toString)

                hx2 = Hbase_get(conn, "zhouqi2", current_dianpu, "h_hour", "2")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (zq2_hour - hx2.toInt).toDouble / hx2.toDouble
                  Hbase_insert(conn, "zhouqi2", current_dianpu, "h_hour", "1", x.toString)
                }
                Hbase_insert(conn, "zhouqi2", current_dianpu, "h_hour", "2", zq2_hour.toString)
                hx2 = Hbase_get(conn, "zhouqi3", current_dianpu, "h_hour", "2")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (zq3_hour - hx2.toInt).toDouble / hx2.toDouble
                  Hbase_insert(conn, "zhouqi3", current_dianpu, "h_hour", "1", x.toString)
                }
                Hbase_insert(conn, "zhouqi3", current_dianpu, "h_hour", "2", zq3_hour.toString)
                hx2 = Hbase_get(conn, "zhouqi4", current_dianpu, "h_hour", "2")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (zq4_hour - hx2.toInt).toDouble / hx2.toDouble
                  Hbase_insert(conn, "zhouqi4", current_dianpu, "h_hour", "1", x.toString)
                }
                Hbase_insert(conn, "zhouqi4", current_dianpu, "h_hour", "2", zq4_hour.toString)
                hx2 = Hbase_get(conn, "zhouqi5", current_dianpu, "h_hour", "2")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (zq5_hour - hx2.toInt).toDouble / hx2.toDouble
                  Hbase_insert(conn, "zhouqi5", current_dianpu, "h_hour", "1", x.toString)
                }
                Hbase_insert(conn, "zhouqi5", current_dianpu, "h_hour", "2", zq5_hour.toString)

                //驻点时长记录
                xxx("zhudian1", "hour", zd1_hour.toString, current_dianpu)
                xxx("zhudian2", "hour", zd2_hour.toString, current_dianpu)
                xxx("zhudian3", "hour", zd3_hour.toString, current_dianpu)
                xxx("zhudian4", "hour", zd4_hour.toString, current_dianpu)
                //驻点时长环比
                hx2 = Hbase_get(conn, "zhudian1", current_dianpu, "h_hour", "2")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (zd1_hour - hx2.toInt).toDouble / hx2.toDouble
                  Hbase_insert(conn, "zhudian1", current_dianpu, "h_hour", "1", x.toString)
                }
                Hbase_insert(conn, "zhudian1", current_dianpu, "h_hour", "2", zd1_hour.toString)
                hx2 = Hbase_get(conn, "zhudian2", current_dianpu, "h_hour", "2")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (zd2_hour - hx2.toInt).toDouble / hx2.toDouble
                  Hbase_insert(conn, "zhudian2", current_dianpu, "h_hour", "1", x.toString)
                }
                Hbase_insert(conn, "zhudian2", current_dianpu, "h_hour", "2", zd2_hour.toString)
                hx2 = Hbase_get(conn, "zhudian3", current_dianpu, "h_hour", "2")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (zd3_hour - hx2.toInt).toDouble / hx2.toDouble
                  Hbase_insert(conn, "zhudian3", current_dianpu, "h_hour", "1", x.toString)
                }
                Hbase_insert(conn, "zhudian3", current_dianpu, "h_hour", "2", zd3_hour.toString)
                hx2 = Hbase_get(conn, "zhudian4", current_dianpu, "h_hour", "2")
                if (hx2 != null && hx2.toInt != 0) {
                  val x: Double = (zd4_hour - hx2.toInt).toDouble / hx2.toDouble
                  Hbase_insert(conn, "zhudian4", current_dianpu, "h_hour", "1", x.toString)
                }
                Hbase_insert(conn, "zhudian4", current_dianpu, "h_hour", "2", zd4_hour.toString)


                last_day = Hbase_get(conn,"time_jilu",current_dianpu,"last_day","1").toInt
                last_month = Hbase_get(conn,"time_jilu",current_dianpu,"last_month","1").toInt
                last_week = Hbase_get(conn,"time_jilu",current_dianpu,"last_week","1").toInt

                last_day -= 1
                last_month -= 1
                last_week -= 1

                Hbase_insert(conn,"time_jilu",current_dianpu,"last_day","1",last_day.toString)
                Hbase_insert(conn,"time_jilu",current_dianpu,"last_month","1",last_month.toString)
                Hbase_insert(conn,"time_jilu",current_dianpu,"last_week","1",last_week.toString)


                if (last_day == 0) {
                  Hbase_insert(conn,"time_jilu",current_dianpu,"last_day","1","24")
                  val hh = df_dianpu_h.format(new Date())

                  //客流、入店天预测
                  val out_fli1 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_keliu_day", true)
                  /** **********/
                  out_fli1.write(DDD + "," + ke_day.toString + "\n")
                  /** **********/
                  out_fli1.close()
                  val raw_data = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_keliu_day")
                  val map_data = raw_data.map { x =>
                    val split_list = x.split(",")
                    (split_list(0).toInt, split_list(1).toInt)
                  }
                  var redict_re_double: Double = 0
                  if (map_data.count() >= 30) {
                    val dfx = sqcX.createDataFrame(map_data)
                    val datax = dfx.toDF("day", "keliu")
                    val colArray = Array("day")
                    val assembler = new VectorAssembler().setInputCols(colArray).setOutputCol("features")
                    val vecDF: DataFrame = assembler.transform(datax)
                    val out_fli2 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_keliu_day_pr")
                    /** **********/
                    out_fli2.write(kdd.toString + ",0\n")
                    /** **********/
                    out_fli2.close()
                    val raw_data_predict = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_keliu_day_pr")
                    val map_data_for_predict = raw_data_predict.map { x =>
                      val split_list = x.split(",")
                      (split_list(0).toInt, split_list(1).toInt)
                    }
                    val df_for_predict = sqcX.createDataFrame(map_data_for_predict)
                    val data_for_predict = df_for_predict.toDF("day", "keliu")
                    val colArray_for_predict = Array("day")
                    val assembler_for_predict = new VectorAssembler().setInputCols(colArray_for_predict).setOutputCol("features")
                    val vecDF_for_predict: DataFrame = assembler_for_predict.transform(data_for_predict)
                    // 建立模型，预测keliu
                    // 设置线性回归参数
                    val lr13 = new LinearRegression()
                    val lr2 = lr13.setFeaturesCol("features").setLabelCol("keliu").setFitIntercept(true)
                    // RegParam：正则化
                    val lr3 = lr2.setMaxIter(10).setRegParam(0.3).setElasticNetParam(0.8)
                    val lr = lr3
                    // 将训练集合代入模型进行训练
                    val lrModel = lr.fit(vecDF)
                    // 输出模型全部参数
                    lrModel.extractParamMap()
                    val predictions: DataFrame = lrModel.transform(vecDF_for_predict)
                    //println("输出预测结果")
                    val predict_result: DataFrame = predictions.selectExpr("prediction")
                    val listRow = predict_result.rdd.collect()
                    val ms = listRow(0).toString()
                    val redict_re = ms.slice(1, ms.length - 1)
                    //println(redict_re.toDouble.toInt)
                    redict_re_double = redict_re.toDouble
                    Hbase_insert(conn, "keliu_pr", current_dianpu, "day", "1", redict_re.toDouble.toInt.toString)
                  }

                  val out_fli11 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_rudian_day", true)
                  /** **********/
                  out_fli11.write(DDD + "," + ru_day.toString + "\n")
                  /** **********/
                  out_fli11.close()
                  val raw_data1 = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_rudian_day")
                  val map_data1 = raw_data1.map { x =>
                    val split_list = x.split(",")
                    (split_list(0).toInt, split_list(1).toInt)
                  }
                  if (map_data1.count() >= 30) {
                    val dfx1 = sqcX.createDataFrame(map_data1)
                    val datax1 = dfx1.toDF("day", "rudian")
                    val colArray1 = Array("day")
                    val assembler1 = new VectorAssembler().setInputCols(colArray1).setOutputCol("features")
                    val vecDF1: DataFrame = assembler1.transform(datax1)
                    val out_fli21 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_rudian_day_pr")
                    /** **********/
                    out_fli21.write(kdd.toString + ",0\n")
                    /** **********/
                    out_fli21.close()
                    val raw_data_predict1 = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_rudian_day_pr")
                    val map_data_for_predict1 = raw_data_predict1.map { x =>
                      val split_list = x.split(",")
                      (split_list(0).toInt, split_list(1).toInt)
                    }
                    val df_for_predict1 = sqcX.createDataFrame(map_data_for_predict1)
                    val data_for_predict1 = df_for_predict1.toDF("day", "rudian")
                    val colArray_for_predict1 = Array("day")
                    val assembler_for_predict1 = new VectorAssembler().setInputCols(colArray_for_predict1).setOutputCol("features")
                    val vecDF_for_predict1: DataFrame = assembler_for_predict1.transform(data_for_predict1)
                    // 建立模型，预测rudian
                    // 设置线性回归参数
                    val lr11 = new LinearRegression()
                    val lr21 = lr11.setFeaturesCol("features").setLabelCol("rudian").setFitIntercept(true)
                    // RegParam：正则化
                    val lr31 = lr21.setMaxIter(10).setRegParam(0.3).setElasticNetParam(0.8)
                    val lr1 = lr31
                    // 将训练集合代入模型进行训练
                    val lrModel1 = lr1.fit(vecDF1)
                    // 输出模型全部参数
                    lrModel1.extractParamMap()
                    val predictions1: DataFrame = lrModel1.transform(vecDF_for_predict1)
                    //println("输出预测结果")
                    val predict_result1: DataFrame = predictions1.selectExpr("prediction")
                    val listRow1 = predict_result1.rdd.collect()
                    val ms1 = listRow1(0).toString()
                    val redict_re1 = ms1.slice(1, ms1.length - 1)
                    //println(redict_re.toDouble.toInt)
                    Hbase_insert(conn, "rudian_pr", current_dianpu, "day", "1", redict_re1.toDouble.toInt.toString)
                    Hbase_insert(conn, "rudr_pr", current_dianpu, "day", "1", ((redict_re_double.toInt.toDouble - redict_re1.toDouble.toInt.toDouble) / redict_re_double.toInt.toDouble).toString)
                  }


                  //天环比、记录3次
                  var dx = Hbase_get(conn, "keliu", current_dianpu, "day", "3")
                  if (dx != null) {
                    Hbase_insert(conn, "keliu", current_dianpu, "day", "4", dx)
                  }
                  dx = Hbase_get(conn, "keliu", current_dianpu, "day", "2")
                  if (dx != null) {
                    Hbase_insert(conn, "keliu", current_dianpu, "day", "3", dx)
                  }
                  var dx2 = Hbase_get(conn, "keliu", current_dianpu, "day", "1")
                  if (dx2 != null && dx2.toInt != 0) {
                    val x: Double = (ke_day - dx2.toInt).toDouble / dx2.toDouble
                    Hbase_insert(conn, "keliu", current_dianpu, "h_day", "1", x.toString)
                    Hbase_insert(conn, "keliu", current_dianpu, "day", "2", dx2)
                  }
                  Hbase_insert(conn, "keliu", current_dianpu, "day", "1", ke_day.toString)

                  dx = Hbase_get(conn, "rudian", current_dianpu, "day", "3")
                  if (dx != null) {
                    Hbase_insert(conn, "rudian", current_dianpu, "day", "4", dx)
                  }
                  dx = Hbase_get(conn, "rudian", current_dianpu, "day", "2")
                  if (dx != null) {
                    Hbase_insert(conn, "rudian", current_dianpu, "day", "3", dx)
                  }
                  dx2 = Hbase_get(conn, "rudian", current_dianpu, "day", "1")
                  if (dx2 != null && dx2.toInt != 0) {
                    val x: Double = (ru_day - dx2.toInt).toDouble / dx2.toDouble
                    Hbase_insert(conn, "rudian", current_dianpu, "h_day", "1", x.toString)
                    Hbase_insert(conn, "rudian", current_dianpu, "day", "2", dx2)
                  }
                  Hbase_insert(conn, "rudian", current_dianpu, "day", "1", ru_day.toString)

                  rur_day = ru_day.toDouble / ke_day.toDouble
                  dx = Hbase_get(conn, "rudr", current_dianpu, "day", "3")
                  if (dx != null) {
                    Hbase_insert(conn, "rudr", current_dianpu, "day", "4", dx)
                  }
                  dx = Hbase_get(conn, "rudr", current_dianpu, "day", "2")
                  if (dx != null) {
                    Hbase_insert(conn, "rudr", current_dianpu, "day", "3", dx)
                  }
                  dx2 = Hbase_get(conn, "rudr", current_dianpu, "day", "1")
                  if (dx2 != null && dx2.toInt != 0) {
                    val x: Double = (rur_day - dx2.toDouble) / dx2.toDouble
                    Hbase_insert(conn, "rudr", current_dianpu, "h_day", "1", x.toString)
                    Hbase_insert(conn, "rudr", current_dianpu, "day", "2", dx2)
                  }
                  Hbase_insert(conn, "rudr", current_dianpu, "day", "1", rur_day.toString)

                  xxx("zhouqi1", "day", zq1_day.toString, current_dianpu)
                  xxx("zhouqi2", "day", zq2_day.toString, current_dianpu)
                  xxx("zhouqi3", "day", zq3_day.toString, current_dianpu)
                  xxx("zhouqi4", "day", zq4_day.toString, current_dianpu)
                  xxx("zhouqi5", "day", zq5_day.toString, current_dianpu)

                  dx2 = Hbase_get(conn, "zhouqi1", current_dianpu, "h_day", "2")
                  if (dx2 != null && dx2.toInt != 0) {
                    val x: Double = (zq1_day - dx2.toInt).toDouble / dx2.toDouble
                    Hbase_insert(conn, "zhouqi1", current_dianpu, "h_day", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi1", current_dianpu, "h_day", "2", zq1_day.toString)
                  dx2 = Hbase_get(conn, "zhouqi2", current_dianpu, "h_day", "2")
                  if (dx2 != null && dx2.toInt != 0) {
                    val x: Double = (zq2_day - dx2.toInt).toDouble / dx2.toDouble
                    Hbase_insert(conn, "zhouqi2", current_dianpu, "h_day", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi2", current_dianpu, "h_day", "2", zq2_day.toString)
                  dx2 = Hbase_get(conn, "zhouqi3", current_dianpu, "h_day", "2")
                  if (dx2 != null && dx2.toInt != 0) {
                    val x: Double = (zq3_day - dx2.toInt).toDouble / dx2.toDouble
                    Hbase_insert(conn, "zhouqi3", current_dianpu, "h_day", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi3", current_dianpu, "h_day", "2", zq3_day.toString)
                  dx2 = Hbase_get(conn, "zhouqi4", current_dianpu, "h_day", "2")
                  if (dx2 != null && dx2.toInt != 0) {
                    val x: Double = (zq4_day - dx2.toInt).toDouble / dx2.toDouble
                    Hbase_insert(conn, "zhouqi4", current_dianpu, "h_day", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi4", current_dianpu, "h_day", "2", zq4_day.toString)
                  dx2 = Hbase_get(conn, "zhouqi5", current_dianpu, "h_day", "2")
                  if (dx2 != null && dx2.toInt != 0) {
                    val x: Double = (zq5_day - dx2.toInt).toDouble / dx2.toDouble
                    Hbase_insert(conn, "zhouqi5", current_dianpu, "h_day", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi5", current_dianpu, "h_day", "2", zq5_day.toString)

                  xms = new_day.toDouble / (old_day + new_day).toDouble
                  hx2 = Hbase_get(conn, "new_old", current_dianpu, "h_day", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (xms - hx2.toDouble) / hx2.toDouble
                    Hbase_insert(conn, "new_old", current_dianpu, "h_day", "1", x.toString)
                  }
                  Hbase_insert(conn, "new_old", current_dianpu, "h_day", "2", xms.toString)
                  xxx("new_old", "day", xms.toString, current_dianpu)

                  xxx("zhudian1", "day", zd1_day.toString, current_dianpu)
                  xxx("zhudian2", "day", zd2_day.toString, current_dianpu)
                  xxx("zhudian3", "day", zd3_day.toString, current_dianpu)
                  xxx("zhudian4", "day", zd4_day.toString, current_dianpu)
                  hx2 = Hbase_get(conn, "zhudian1", current_dianpu, "h_day", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (zd1_day - hx2.toInt).toDouble / hx2.toDouble
                    Hbase_insert(conn, "zhudian1", current_dianpu, "h_day", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhudian1", current_dianpu, "h_day", "2", zd1_day.toString)
                  hx2 = Hbase_get(conn, "zhudian2", current_dianpu, "h_day", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (zd2_day - hx2.toInt).toDouble / hx2.toDouble
                    Hbase_insert(conn, "zhudian2", current_dianpu, "h_day", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhudian2", current_dianpu, "h_day", "2", zd2_day.toString)
                  hx2 = Hbase_get(conn, "zhudian3", current_dianpu, "h_day", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (zd3_day - hx2.toInt).toDouble / hx2.toDouble
                    Hbase_insert(conn, "zhudian3", current_dianpu, "h_day", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhudian3", current_dianpu, "h_day", "2", zd3_day.toString)
                  hx2 = Hbase_get(conn, "zhudian4", current_dianpu, "h_day", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (zd4_day - hx2.toInt).toDouble / hx2.toDouble
                    Hbase_insert(conn, "zhudian4", current_dianpu, "h_day", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhudian4", current_dianpu, "h_day", "2", zd4_day.toString)

                  //天各店铺统计
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "keliu", ke_day.toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "rudian", ru_day.toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "rudr", (ru_day / ke_day).toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "zhouqi1", zq1_day.toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "zhouqi2", zq2_day.toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "zhouqi3", zq3_day.toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "zhouqi4", zq4_day.toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "zhouqi5", zq5_day.toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "new", new_day.toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "old", old_day.toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "zhudian1", zd1_day.toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "zhudian2", zd2_day.toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "zhudian3", zd3_day.toString)
                  Hbase_insert(conn, "dianpu_history", current_dianpu, hh, "zhudian4", zd4_day.toString)

                  ru_day = 0
                  ke_day = 0
                  zq1_day = 0
                  zq2_day = 0
                  zq3_day = 0
                  zq4_day = 0
                  zq5_day = 0
                  new_day = 0
                  old_day = 0
                  zd1_day = 0
                  zd2_day = 0
                  zd3_day = 0
                  zd4_day = 0
                }
                else {
                  ke_day += ke_hour
                  ru_day += ru_hour
                  zq1_day += zq1_hour
                  zq2_day += zq2_hour
                  zq3_day += zq3_hour
                  zq4_day += zq4_hour
                  zq5_day += zq5_hour
                  new_day += new_hour
                  old_day += old_hour
                  zd1_day += zd1_hour
                  zd2_day += zd2_hour
                  zd3_day += zd3_hour
                  zd4_day += zd4_hour
                }

                if (last_week == 0) {
                  Hbase_insert(conn,"time_jilu",current_dianpu,"last_week","1","168")

                  //客流、入店天周预测
                  val out_fli1 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_keliu_week", true)
                  /** **********/
                  out_fli1.write(eee + "," + ke_week.toString + "\n")
                  /** **********/
                  out_fli1.close()
                  val raw_data = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_keliu_week")
                  val map_data = raw_data.map { x =>
                    val split_list = x.split(",")
                    (split_list(0).toInt, split_list(1).toInt)
                  }
                  var redict_re_double: Double = 0
                  if (map_data.count() >= 7) {
                    val dfx = sqcX.createDataFrame(map_data)
                    val datax = dfx.toDF("week", "keliu")
                    val colArray = Array("week")
                    val assembler = new VectorAssembler().setInputCols(colArray).setOutputCol("features")
                    val vecDF: DataFrame = assembler.transform(datax)
                    val out_fli2 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_keliu_week_pr")
                    /** **********/
                    out_fli2.write(kww.toString + ",0\n")
                    /** **********/
                    out_fli2.close()
                    val raw_data_predict = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_keliu_week_pr")
                    val map_data_for_predict = raw_data_predict.map { x =>
                      val split_list = x.split(",")
                      (split_list(0).toInt, split_list(1).toInt)
                    }
                    val df_for_predict = sqcX.createDataFrame(map_data_for_predict)
                    val data_for_predict = df_for_predict.toDF("week", "keliu")
                    val colArray_for_predict = Array("week")
                    val assembler_for_predict = new VectorAssembler().setInputCols(colArray_for_predict).setOutputCol("features")
                    val vecDF_for_predict: DataFrame = assembler_for_predict.transform(data_for_predict)
                    // 建立模型，预测keliu
                    // 设置线性回归参数
                    val lr13 = new LinearRegression()
                    val lr2 = lr13.setFeaturesCol("features").setLabelCol("keliu").setFitIntercept(true)
                    // RegParam：正则化
                    val lr3 = lr2.setMaxIter(10).setRegParam(0.3).setElasticNetParam(0.8)
                    val lr = lr3
                    // 将训练集合代入模型进行训练
                    val lrModel = lr.fit(vecDF)
                    // 输出模型全部参数
                    lrModel.extractParamMap()
                    val predictions: DataFrame = lrModel.transform(vecDF_for_predict)
                    //println("输出预测结果")
                    val predict_result: DataFrame = predictions.selectExpr("prediction")
                    val listRow = predict_result.rdd.collect()
                    val ms = listRow(0).toString()
                    val redict_re = ms.slice(1, ms.length - 1)
                    //println(redict_re.toDouble.toInt)
                    redict_re_double = redict_re.toDouble
                    Hbase_insert(conn, "keliu_pr", current_dianpu, "week", "1", redict_re.toDouble.toInt.toString)

                    val raw_data_predict3 = sc.textFile("/home/hadoop/Documents/week_pr")
                    val map_data_for_predict3 = raw_data_predict3.map { x =>
                      val split_list = x.split(",")
                      (split_list(0).toInt, split_list(1).toInt)
                    }
                    val df_for_predict3 = sqcX.createDataFrame(map_data_for_predict3)
                    val data_for_predict3 = df_for_predict3.toDF("week", "keliu")
                    val colArray_for_predict3 = Array("week")
                    val assembler_for_predict3 = new VectorAssembler().setInputCols(colArray_for_predict3).setOutputCol("features")
                    val vecDF_for_predict3: DataFrame = assembler_for_predict3.transform(data_for_predict3)
                    val predictions3: DataFrame = lrModel.transform(vecDF_for_predict3)
                    val predict_result3: DataFrame = predictions3.selectExpr("prediction")
                    val listRow3 = predict_result3.rdd.collect()
                    var ms3 = listRow3(0).toString()
                    var redict_re3 = ms3.slice(1, ms3.length - 1)
                    Hbase_insert(conn, "week_pr", current_dianpu, "values", "1", redict_re3)
                    ms3 = listRow3(1).toString()
                    redict_re3 = ms3.slice(1, ms3.length - 1)
                    Hbase_insert(conn, "week_pr", current_dianpu, "values", "2", redict_re3)
                    ms3 = listRow3(2).toString()
                    redict_re3 = ms3.slice(1, ms3.length - 1)
                    Hbase_insert(conn, "week_pr", current_dianpu, "values", "3", redict_re3)
                    ms3 = listRow3(3).toString()
                    redict_re3 = ms3.slice(1, ms3.length - 1)
                    Hbase_insert(conn, "week_pr", current_dianpu, "values", "4", redict_re3)
                    ms3 = listRow3(4).toString()
                    redict_re3 = ms3.slice(1, ms3.length - 1)
                    Hbase_insert(conn, "week_pr", current_dianpu, "values", "5", redict_re3)
                    ms3 = listRow3(5).toString()
                    redict_re3 = ms3.slice(1, ms3.length - 1)
                    Hbase_insert(conn, "week_pr", current_dianpu, "values", "6", redict_re3)
                    ms3 = listRow3(6).toString()
                    redict_re3 = ms3.slice(1, ms3.length - 1)
                    Hbase_insert(conn, "week_pr", current_dianpu, "values", "7", redict_re3)
                  }

                  val out_fli11 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_rudian_week", true)
                  /** **********/
                  out_fli11.write(eee + "," + ru_week.toString + "\n")
                  /** **********/
                  out_fli11.close()
                  val raw_data1 = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_rudian_week")
                  val map_data1 = raw_data1.map { x =>
                    val split_list = x.split(",")
                    (split_list(0).toInt, split_list(1).toInt)
                  }
                  if (map_data1.count() >= 7) {
                    val dfx1 = sqcX.createDataFrame(map_data1)
                    val datax1 = dfx1.toDF("week", "rudian")
                    val colArray1 = Array("week")
                    val assembler1 = new VectorAssembler().setInputCols(colArray1).setOutputCol("features")
                    val vecDF1: DataFrame = assembler1.transform(datax1)
                    val out_fli21 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_rudian_week_pr")
                    /** **********/
                    out_fli21.write(kww.toString + ",0\n")
                    /** **********/
                    out_fli21.close()
                    val raw_data_predict1 = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_rudian_week_pr")
                    val map_data_for_predict1 = raw_data_predict1.map { x =>
                      val split_list = x.split(",")
                      (split_list(0).toInt, split_list(1).toInt)
                    }
                    val df_for_predict1 = sqcX.createDataFrame(map_data_for_predict1)
                    val data_for_predict1 = df_for_predict1.toDF("week", "rudian")
                    val colArray_for_predict1 = Array("week")
                    val assembler_for_predict1 = new VectorAssembler().setInputCols(colArray_for_predict1).setOutputCol("features")
                    val vecDF_for_predict1: DataFrame = assembler_for_predict1.transform(data_for_predict1)
                    // 建立模型，预测rudian
                    // 设置线性回归参数
                    val lr11 = new LinearRegression()
                    val lr21 = lr11.setFeaturesCol("features").setLabelCol("rudian").setFitIntercept(true)
                    // RegParam：正则化
                    val lr31 = lr21.setMaxIter(10).setRegParam(0.3).setElasticNetParam(0.8)
                    val lr1 = lr31
                    // 将训练集合代入模型进行训练
                    val lrModel1 = lr1.fit(vecDF1)
                    // 输出模型全部参数
                    lrModel1.extractParamMap()
                    val predictions1: DataFrame = lrModel1.transform(vecDF_for_predict1)
                    //println("输出预测结果")
                    val predict_result1: DataFrame = predictions1.selectExpr("prediction")
                    val listRow1 = predict_result1.rdd.collect()
                    val ms1 = listRow1(0).toString()
                    val redict_re1 = ms1.slice(1, ms1.length - 1)
                    //println(redict_re.toDouble.toInt)
                    Hbase_insert(conn, "rudian_pr", current_dianpu, "week", "1", redict_re1.toDouble.toInt.toString)
                    Hbase_insert(conn, "rudr_pr", current_dianpu, "week", "1", ((redict_re_double.toInt.toDouble - redict_re1.toDouble.toInt.toDouble) / redict_re_double.toInt.toDouble).toString)
                  }


                  var wx = Hbase_get(conn, "keliu", current_dianpu, "week", "3")
                  if (wx != null) {
                    Hbase_insert(conn, "keliu", current_dianpu, "week", "4", wx)
                  }
                  var wx2 = Hbase_get(conn, "keliu", current_dianpu, "week", "2")
                  if (wx2 != null) {
                    Hbase_insert(conn, "keliu", current_dianpu, "week", "3", wx2)
                  }
                  var wx3 = Hbase_get(conn, "keliu", current_dianpu, "week", "1")
                  if (wx3 != null && wx3.toInt != 0) {
                    val x: Double = (ke_week - wx3.toInt).toDouble / wx3.toDouble
                    Hbase_insert(conn, "keliu", current_dianpu, "h_week", "1", x.toString)
                    Hbase_insert(conn, "keliu", current_dianpu, "week", "2", wx3)
                  }
                  Hbase_insert(conn, "keliu", current_dianpu, "week", "1", ke_week.toString)

                  wx = Hbase_get(conn, "rudian", current_dianpu, "week", "3")
                  if (wx != null) {
                    Hbase_insert(conn, "rudian", current_dianpu, "week", "4", wx)
                  }
                  wx2 = Hbase_get(conn, "rudian", current_dianpu, "week", "2")
                  if (wx2 != null) {
                    Hbase_insert(conn, "rudian", current_dianpu, "week", "3", wx2)
                  }
                  wx3 = Hbase_get(conn, "rudian", current_dianpu, "week", "1")
                  if (wx3 != null && wx3.toInt != 0) {
                    val x: Double = (ru_week - wx3.toInt).toDouble / wx3.toDouble
                    Hbase_insert(conn, "rudian", current_dianpu, "h_week", "1", x.toString)
                    Hbase_insert(conn, "rudian", current_dianpu, "week", "2", wx3)
                  }
                  Hbase_insert(conn, "rudian", current_dianpu, "week", "1", ru_week.toString)

                  rur_week = ru_week.toDouble / ke_week.toDouble
                  wx = Hbase_get(conn, "rudr", current_dianpu, "week", "3")
                  if (wx != null) {
                    Hbase_insert(conn, "rudr", current_dianpu, "week", "4", wx)
                  }
                  wx2 = Hbase_get(conn, "rudr", current_dianpu, "week", "2")
                  if (wx2 != null) {
                    Hbase_insert(conn, "rudr", current_dianpu, "week", "3", wx2)
                  }
                  wx3 = Hbase_get(conn, "rudr", current_dianpu, "week", "1")
                  if (wx3 != null && wx3.toInt != 0) {
                    val x: Double = (rur_week - wx3.toDouble) / wx3.toDouble
                    Hbase_insert(conn, "rudr", current_dianpu, "h_week", "1", x.toString)
                    Hbase_insert(conn, "rudr", current_dianpu, "week", "2", wx3)
                  }
                  Hbase_insert(conn, "rudr", current_dianpu, "week", "1", rur_week.toString)
                  xxx("zhouqi1", "week", zq1_week.toString, current_dianpu)
                  xxx("zhouqi2", "week", zq2_week.toString, current_dianpu)
                  xxx("zhouqi3", "week", zq3_week.toString, current_dianpu)
                  xxx("zhouqi4", "week", zq4_week.toString, current_dianpu)
                  xxx("zhouqi5", "week", zq5_week.toString, current_dianpu)
                  wx3 = Hbase_get(conn, "zhouqi1", current_dianpu, "h_week", "2")
                  if (wx3 != null && wx3.toInt != 0) {
                    val x: Double = (zq1_week - wx3.toDouble) / wx3.toDouble
                    Hbase_insert(conn, "zhouqi1", current_dianpu, "h_week", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi1", current_dianpu, "h_week", "2", zq1_week.toString)
                  wx3 = Hbase_get(conn, "zhouqi2", current_dianpu, "h_week", "2")
                  if (wx3 != null && wx3.toInt != 0) {
                    val x: Double = (zq2_week - wx3.toDouble) / wx3.toDouble
                    Hbase_insert(conn, "zhouqi2", current_dianpu, "h_week", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi2", current_dianpu, "h_week", "2", zq2_week.toString)
                  wx3 = Hbase_get(conn, "zhouqi3", current_dianpu, "h_week", "2")
                  if (wx3 != null && wx3.toInt != 0) {
                    val x: Double = (zq3_week - wx3.toDouble) / wx3.toDouble
                    Hbase_insert(conn, "zhouqi3", current_dianpu, "h_week", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi3", current_dianpu, "h_week", "2", zq3_week.toString)
                  wx3 = Hbase_get(conn, "zhouqi4", current_dianpu, "h_week", "2")
                  if (wx3 != null && wx3.toInt != 0) {
                    val x: Double = (zq4_week - wx3.toDouble) / wx3.toDouble
                    Hbase_insert(conn, "zhouqi4", current_dianpu, "h_week", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi4", current_dianpu, "h_week", "2", zq4_week.toString)
                  wx3 = Hbase_get(conn, "zhouqi5", current_dianpu, "h_week", "2")
                  if (wx3 != null && wx3.toInt != 0) {
                    val x: Double = (zq5_week - wx3.toDouble) / wx3.toDouble
                    Hbase_insert(conn, "zhouqi5", current_dianpu, "h_week", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi5", current_dianpu, "h_week", "2", zq5_week.toString)

                  xms = new_week.toDouble / (old_week + new_week).toDouble
                  hx2 = Hbase_get(conn, "new_old", current_dianpu, "h_week", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (xms - hx2.toDouble) / hx2.toDouble
                    Hbase_insert(conn, "new_old", current_dianpu, "h_week", "1", x.toString)
                  }
                  Hbase_insert(conn, "new_old", current_dianpu, "h_week", "2", xms.toString)
                  xxx("new_old", "week", xms.toString, current_dianpu)

                  xxx("zhudian1", "week", zd1_week.toString, current_dianpu)
                  xxx("zhudian2", "week", zd2_week.toString, current_dianpu)
                  xxx("zhudian3", "week", zd3_week.toString, current_dianpu)
                  xxx("zhudian4", "week", zd4_week.toString, current_dianpu)
                  hx2 = Hbase_get(conn, "zhudian1", current_dianpu, "h_week", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (zd1_week - hx2.toInt).toDouble / hx2.toDouble
                    Hbase_insert(conn, "zhudian1", current_dianpu, "h_week", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhudian1", current_dianpu, "h_week", "2", zd1_week.toString)
                  hx2 = Hbase_get(conn, "zhudian2", current_dianpu, "h_week", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (zd2_week - hx2.toInt).toDouble / hx2.toDouble
                    Hbase_insert(conn, "zhudian2", current_dianpu, "h_week", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhudian2", current_dianpu, "h_week", "2", zd2_week.toString)
                  hx2 = Hbase_get(conn, "zhudian3", current_dianpu, "h_week", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (zd3_week - hx2.toInt).toDouble / hx2.toDouble
                    Hbase_insert(conn, "zhudian3", current_dianpu, "h_week", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhudian3", current_dianpu, "h_week", "2", zd3_week.toString)
                  hx2 = Hbase_get(conn, "zhudian4", current_dianpu, "h_week", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (zd4_week - hx2.toInt).toDouble / hx2.toDouble
                    Hbase_insert(conn, "zhudian4", current_dianpu, "h_week", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhudian4", current_dianpu, "h_week", "2", zd4_week.toString)

                  Hbase_insert(conn, "dianpu", current_dianpu, "W_Keliu", "1", ru_week.toString)

                  zd1_week = 0
                  zd2_week = 0
                  zd3_week = 0
                  zd4_week = 0
                  ru_week = 0
                  ke_week = 0
                  zq1_week = 0
                  zq2_week = 0
                  zq3_week = 0
                  zq4_week = 0
                  zq5_week = 0
                  new_week = 0
                  old_week = 0
                }
                else {
                  ke_week += ke_hour
                  ru_week += ru_hour
                  zq1_week += zq1_hour
                  zq2_week += zq2_hour
                  zq3_week += zq3_hour
                  zq5_week += zq5_hour
                  zq4_week += zq4_hour
                  new_week += new_hour
                  old_week += old_hour
                  zd1_week += zd1_hour
                  zd2_week += zd2_hour
                  zd3_week += zd3_hour
                  zd4_week += zd4_hour
                }

                if (last_month == 0) {
                  Hbase_insert(conn,"time_jilu",current_dianpu,"last_month","1","720")

                  //客流、入店月预测
                  val out_fli1 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_keliu_month", true)
                  /** **********/
                  out_fli1.write(MMM + "," + ke_month.toString + "\n")
                  /** **********/
                  out_fli1.close()
                  val raw_data = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_keliu_month")
                  val map_data = raw_data.map { x =>
                    val split_list = x.split(",")
                    (split_list(0).toInt, split_list(1).toInt)
                  }
                  var redict_re_double: Double = 0
                  if (map_data.count() >= 30) {
                    val dfx = sqcX.createDataFrame(map_data)
                    val datax = dfx.toDF("month", "keliu")
                    val colArray = Array("month")
                    val assembler = new VectorAssembler().setInputCols(colArray).setOutputCol("features")
                    val vecDF: DataFrame = assembler.transform(datax)
                    val out_fli2 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_keliu_month_pr")
                    /** **********/
                    out_fli2.write(kmm.toString + ",0\n")
                    /** **********/
                    out_fli2.close()
                    val raw_data_predict = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_keliu_month_pr")
                    val map_data_for_predict = raw_data_predict.map { x =>
                      val split_list = x.split(",")
                      (split_list(0).toInt, split_list(1).toInt)
                    }
                    val df_for_predict = sqcX.createDataFrame(map_data_for_predict)
                    val data_for_predict = df_for_predict.toDF("month", "keliu")
                    val colArray_for_predict = Array("month")
                    val assembler_for_predict = new VectorAssembler().setInputCols(colArray_for_predict).setOutputCol("features")
                    val vecDF_for_predict: DataFrame = assembler_for_predict.transform(data_for_predict)
                    // 建立模型，预测keliu
                    // 设置线性回归参数
                    val lr13 = new LinearRegression()
                    val lr2 = lr13.setFeaturesCol("features").setLabelCol("keliu").setFitIntercept(true)
                    // RegParam：正则化
                    val lr3 = lr2.setMaxIter(10).setRegParam(0.3).setElasticNetParam(0.8)
                    val lr = lr3
                    // 将训练集合代入模型进行训练
                    val lrModel = lr.fit(vecDF)
                    // 输出模型全部参数
                    lrModel.extractParamMap()
                    val predictions: DataFrame = lrModel.transform(vecDF_for_predict)
                    //println("输出预测结果")
                    val predict_result: DataFrame = predictions.selectExpr("prediction")
                    val listRow = predict_result.rdd.collect()
                    val ms = listRow(0).toString()
                    val redict_re = ms.slice(1, ms.length - 1)
                    //println(redict_re.toDouble.toInt)
                    redict_re_double = redict_re.toDouble
                    Hbase_insert(conn, "keliu_pr", current_dianpu, "month", "1", redict_re.toDouble.toInt.toString)
                  }

                  val out_fli11 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_rudian_month", true)
                  /** **********/
                  out_fli11.write(MMM + "," + ru_month.toString + "\n")
                  /** **********/
                  out_fli11.close()
                  val raw_data1 = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_rudian_month")
                  val map_data1 = raw_data1.map { x =>
                    val split_list = x.split(",")
                    (split_list(0).toInt, split_list(1).toInt)
                  }
                  if (map_data1.count() >= 30) {
                    val dfx1 = sqcX.createDataFrame(map_data1)
                    val datax1 = dfx1.toDF("month", "rudian")
                    val colArray1 = Array("month")
                    val assembler1 = new VectorAssembler().setInputCols(colArray1).setOutputCol("features")
                    val vecDF1: DataFrame = assembler1.transform(datax1)
                    val out_fli21 = new FileWriter("/home/hadoop/Documents/"+current_dianpu+"_rudian_month_pr")
                    /** **********/
                    out_fli21.write(kmm.toString + ",0\n")
                    /** **********/
                    out_fli21.close()
                    val raw_data_predict1 = sc.textFile("/home/hadoop/Documents/"+current_dianpu+"_rudian_month_pr")
                    val map_data_for_predict1 = raw_data_predict1.map { x =>
                      val split_list = x.split(",")
                      (split_list(0).toInt, split_list(1).toInt)
                    }
                    val df_for_predict1 = sqcX.createDataFrame(map_data_for_predict1)
                    val data_for_predict1 = df_for_predict1.toDF("month", "rudian")
                    val colArray_for_predict1 = Array("month")
                    val assembler_for_predict1 = new VectorAssembler().setInputCols(colArray_for_predict1).setOutputCol("features")
                    val vecDF_for_predict1: DataFrame = assembler_for_predict1.transform(data_for_predict1)
                    // 建立模型，预测rudian
                    // 设置线性回归参数
                    val lr11 = new LinearRegression()
                    val lr21 = lr11.setFeaturesCol("features").setLabelCol("rudian").setFitIntercept(true)
                    // RegParam：正则化
                    val lr31 = lr21.setMaxIter(10).setRegParam(0.3).setElasticNetParam(0.8)
                    val lr1 = lr31
                    // 将训练集合代入模型进行训练
                    val lrModel1 = lr1.fit(vecDF1)
                    // 输出模型全部参数
                    lrModel1.extractParamMap()
                    val predictions1: DataFrame = lrModel1.transform(vecDF_for_predict1)
                    //println("输出预测结果")
                    val predict_result1: DataFrame = predictions1.selectExpr("prediction")
                    val listRow1 = predict_result1.rdd.collect()
                    val ms1 = listRow1(0).toString()
                    val redict_re1 = ms1.slice(1, ms1.length - 1)
                    //println(redict_re.toDouble.toInt)
                    Hbase_insert(conn, "rudian_pr", current_dianpu, "month", "1", redict_re1.toDouble.toInt.toString)
                    Hbase_insert(conn, "rudr_pr", current_dianpu, "month", "1", ((redict_re_double.toInt.toDouble - redict_re1.toDouble.toInt.toDouble) / redict_re_double.toInt.toDouble).toString)
                  }


                  var mx = Hbase_get(conn, "keliu", current_dianpu, "month", "2")
                  if (mx != null) {
                    Hbase_insert(conn, "keliu", current_dianpu, "month", "3", mx)
                  }
                  var mx2 = Hbase_get(conn, "keliu", current_dianpu, "month", "1")
                  if (mx2 != null && mx2.toInt != 0) {
                    val x: Double = (ke_month - mx2.toInt).toDouble / mx2.toDouble
                    Hbase_insert(conn, "keliu", current_dianpu, "h_month", "1", x.toString)
                    Hbase_insert(conn, "keliu", current_dianpu, "month", "2", mx2)
                  }
                  Hbase_insert(conn, "keliu", current_dianpu, "month", "1", ke_month.toString)

                  mx = Hbase_get(conn, "rudian", current_dianpu, "month", "2")
                  if (mx != null) {
                    Hbase_insert(conn, "rudian", current_dianpu, "month", "3", mx)
                  }
                  mx2 = Hbase_get(conn, "rudian", current_dianpu, "month", "1")
                  if (mx2 != null && mx2.toInt != 0) {
                    val x: Double = (ru_month - mx2.toInt).toDouble / mx2.toDouble
                    Hbase_insert(conn, "rudian", current_dianpu, "h_month", "1", x.toString)
                    Hbase_insert(conn, "rudian", current_dianpu, "month", "2", mx2)
                  }
                  Hbase_insert(conn, "rudian", current_dianpu, "month", "1", ru_month.toString)

                  rur_month = ru_month.toDouble / ke_month.toDouble
                  mx = Hbase_get(conn, "rudr", current_dianpu, "month", "2")
                  if (mx != null) {
                    Hbase_insert(conn, "rudr", current_dianpu, "month", "3", mx)
                  }
                  mx2 = Hbase_get(conn, "rudr", current_dianpu, "month", "1")
                  if (mx2 != null && mx2.toInt != 0) {
                    val x: Double = (rur_month - mx2.toDouble) / mx2.toDouble
                    Hbase_insert(conn, "rudr", current_dianpu, "h_month", "1", x.toString)
                    Hbase_insert(conn, "rudr", current_dianpu, "month", "2", mx2)
                  }
                  Hbase_insert(conn, "rudr", current_dianpu, "month", "1", rur_month.toString)

                  xxx("zhouqi1", "month", zq1_month.toString, current_dianpu)
                  xxx("zhouqi2", "month", zq2_month.toString, current_dianpu)
                  xxx("zhouqi3", "month", zq3_month.toString, current_dianpu)
                  xxx("zhouqi4", "month", zq4_month.toString, current_dianpu)
                  xxx("zhouqi5", "month", zq5_month.toString, current_dianpu)
                  mx2 = Hbase_get(conn, "zhouqi1", current_dianpu, "h_month", "2")
                  if (mx2 != null && mx2.toInt != 0) {
                    val x: Double = (zq1_month - mx2.toDouble) / mx2.toDouble
                    Hbase_insert(conn, "zhouqi1", current_dianpu, "h_month", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi1", current_dianpu, "h_month", "2", zq1_month.toString)
                  mx2 = Hbase_get(conn, "zhouqi2", current_dianpu, "h_month", "2")
                  if (mx2 != null && mx2.toInt != 0) {
                    val x: Double = (zq2_month - mx2.toDouble) / mx2.toDouble
                    Hbase_insert(conn, "zhouqi2", current_dianpu, "h_month", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi2", current_dianpu, "h_month", "2", zq2_month.toString)
                  mx2 = Hbase_get(conn, "zhouqi3", current_dianpu, "h_month", "2")
                  if (mx2 != null && mx2.toInt != 0) {
                    val x: Double = (zq3_month - mx2.toDouble) / mx2.toDouble
                    Hbase_insert(conn, "zhouqi3", current_dianpu, "h_month", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi3", current_dianpu, "h_month", "2", zq3_month.toString)
                  mx2 = Hbase_get(conn, "zhouqi4", current_dianpu, "h_month", "2")
                  if (mx2 != null && mx2.toInt != 0) {
                    val x: Double = (zq4_month - mx2.toDouble) / mx2.toDouble
                    Hbase_insert(conn, "zhouqi4", current_dianpu, "h_month", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi4", current_dianpu, "h_month", "2", zq4_month.toString)
                  mx2 = Hbase_get(conn, "zhouqi5", current_dianpu, "h_month", "2")
                  if (mx2 != null && mx2.toInt != 0) {
                    val x: Double = (zq5_month - mx2.toDouble) / mx2.toDouble
                    Hbase_insert(conn, "zhouqi5", current_dianpu, "h_month", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhouqi5", current_dianpu, "h_month", "2", zq5_month.toString)

                  xms = new_month.toDouble / (old_month + new_month).toDouble
                  hx2 = Hbase_get(conn, "new_old", current_dianpu, "h_month", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (xms - hx2.toDouble) / hx2.toDouble
                    Hbase_insert(conn, "new_old", current_dianpu, "h_month", "1", x.toString)
                  }
                  Hbase_insert(conn, "new_old", current_dianpu, "h_month", "2", xms.toString)
                  xxx("new_old", "month", xms.toString, current_dianpu)

                  xxx("zhudian1", "month", zd1_month.toString, current_dianpu)
                  xxx("zhudian2", "month", zd2_month.toString, current_dianpu)
                  xxx("zhudian3", "month", zd3_month.toString, current_dianpu)
                  xxx("zhudian4", "month", zd4_month.toString, current_dianpu)
                  hx2 = Hbase_get(conn, "zhudian1", current_dianpu, "h_month", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (zd1_month - hx2.toInt).toDouble / hx2.toDouble
                    Hbase_insert(conn, "zhudian1", current_dianpu, "h_month", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhudian1", current_dianpu, "h_month", "2", zd1_month.toString)
                  hx2 = Hbase_get(conn, "zhudian2", current_dianpu, "h_month", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (zd2_month - hx2.toInt).toDouble / hx2.toDouble
                    Hbase_insert(conn, "zhudian2", current_dianpu, "h_month", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhudian2", current_dianpu, "h_month", "2", zd2_month.toString)
                  hx2 = Hbase_get(conn, "zhudian3", current_dianpu, "h_month", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (zd3_month - hx2.toInt).toDouble / hx2.toDouble
                    Hbase_insert(conn, "zhudian3", current_dianpu, "h_month", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhudian3", current_dianpu, "h_month", "2", zd3_month.toString)
                  hx2 = Hbase_get(conn, "zhudian4", current_dianpu, "h_month", "2")
                  if (hx2 != null && hx2.toInt != 0) {
                    val x: Double = (zd4_month - hx2.toInt).toDouble / hx2.toDouble
                    Hbase_insert(conn, "zhudian4", current_dianpu, "h_month", "1", x.toString)
                  }
                  Hbase_insert(conn, "zhudian4", current_dianpu, "h_month", "2", zd4_month.toString)
                  zd1_month = 0
                  zd2_month = 0
                  zd3_month = 0
                  zd4_month = 0
                  ru_month = 0
                  ke_month = 0
                  zq1_month = 0
                  zq2_month = 0
                  zq3_month = 0
                  zq4_month = 0
                  zq5_month = 0
                  new_month = 0
                  old_month = 0
                }
                else {
                  ke_month += ke_hour
                  ru_month += ru_hour
                  zq1_month += zq1_hour
                  zq2_month += zq2_hour
                  zq3_month += zq3_hour
                  zq4_month += zq4_hour
                  zq5_month += zq5_hour
                  new_month += new_hour
                  old_month += old_hour
                  zd1_month += zd1_hour
                  zd2_month += zd2_hour
                  zd3_month += zd3_hour
                  zd4_month += zd4_hour
                }

                ke_hour = 0
                ru_hour = 0
                zq1_hour = 0
                zq2_hour = 0
                zq3_hour = 0
                zq4_hour = 0
                zq5_hour = 0
                new_hour = 0
                old_hour = 0
                zd1_hour = 0
                zd2_hour = 0
                zd3_hour = 0
                zd4_hour = 0
              }
              else {
                ke_hour += count_all
                ru_hour += count_in
                zq1_hour += t_num(0)
                zq2_hour += t_num(1)
                zq3_hour += t_num(2)
                zq4_hour += t_num(3)
                zq5_hour += t_num(4)
                new_hour += t_num(0)
                old_hour += count_in - x_num(0)
                zd1_hour += h_num(0)
                zd2_hour += h_num(1)
                zd3_hour += h_num(2)
                zd4_hour += h_num(3)
              }

            }
          }
        }
        else {
          val blank_name = Hbase_get(conn, "dianpu", current_dianpu, "WifiId", "1")
          var blank_keliu: Long = 0
          if (blank_name != null) {
            blank_keliu = Hbase_count(blank_name)
            Hbase_insert(conn,"keliu",current_dianpu,"now","1",blank_keliu.toString)
            val chushihua = Hbase_get(conn, "time_jilu", current_dianpu, "chushihua", "1")
            if (chushihua == null) {
              Hbase_insert(conn, "time_jilu", current_dianpu, "last_hour", "1", df.format(new Date()))
            }
            last_hour = Hbase_get(conn, "time_jilu", current_dianpu, "last_hour", "1")
            val new_time = df.format(new Date())

            if (Times.Time_Duration_Minutes(new_time, last_hour) >= 60*24) {
              Hbase_insert(conn, "time_jilu", current_dianpu, "last_hour", "1", df.format(new Date()))
              //********************
              Hbase_insert(conn,"keliu",current_dianpu,"day","1",blank_people.toString)
              blank_people = 0
            }
            else blank_people += blank_keliu
          }
        }
      }
      var dianpu_num2=dianpu_name.length
      var rudian:Long=0
      var keliu:Long=0
      while(dianpu_num2 != 0){
        dianpu_num2-=1
        current_dianpu=dianpu_name(dianpu_num2 - 1)
        //************

        if(current_dianpu.indexOf("blank_") == -1 && current_dianpu!=null){
          rudian+=Hbase_get(conn,"rudian",current_dianpu,"now","1").toInt
        }
        if(current_dianpu!=null){
          keliu+=Hbase_get(conn,"keliu",current_dianpu,"now","1").toInt
        }
      }

      Hbase_insert(conn,"shangcheng","1","keliu","1",keliu.toString)
      Hbase_insert(conn,"shangcheng","1","rudian","1",rudian.toString)



      if(Times.Time_Duration_Minutes(df.format(new Date()),ttime) >= 60){

      }


      var time_dao = true
      while (time_dao) {
        val time2 = df.format(new Date())
        if (Times.Time_Duration_Seconds(time2, time1) >= 3)
          time_dao = false
      }
    }
  }
}