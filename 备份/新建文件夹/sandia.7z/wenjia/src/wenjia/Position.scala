
object Position{
  class xy{
    var x:Double=0
    var y:Double=0
  }
  def position(x1:Double,y1:Double,x2:Double,y2:Double,x3:Double,y3:Double,r1:Double,r2:Double,r3:Double,wucha:Double): xy={
    val dw:xy=null
    val d1 = (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)
    val d2 = (x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3)
    val d3 = (x2 - x3) * (x2 - x3) + (y2 - y3) * (y2 - y3)

    if (((d1 <= (r1 + r2 + wucha) * (r1 + r2 + wucha)) && (d1 >= (r1 + r2 - wucha) * (r1 + r2 - wucha))) || ((d1 <= (Math.abs(r1 - r2) + wucha) * (Math.abs(r1 - r2) + wucha)) && (d1 >= (Math.abs(r1 - r2) - wucha) * (Math.abs(r1 - r2) - wucha)))) {
      dw.x = x1 + (x2 - x1) * (r1 / (r1 + r2))
      dw.y = y1 + (y2 - y1) * (r1 / (r1 + r2))
    }
    else if (((d2 <= (r1 + r3 + wucha) * (r1 + r3 + wucha)) && (d2 >= (r1 + r3 - wucha) * (r1 + r3 - wucha))) || ((d2 <= (Math.abs(r1 - r3) + wucha) * (Math.abs(r1 - r3) + wucha)) && (d2 >= (Math.abs(r1 - r3) - wucha) * (Math.abs(r1 - r3) - wucha)))) {
      dw.x = x1 + (x3 - x1) * (r1 / (r1 + r3))
      dw.y = y1 + (y3 - y1) * (r1 / (r1 + r3))
    }
    else if (((d3 <= (r3 + r2 + wucha) * (r3 + r2 + wucha)) && (d3 >= (r3 + r2 - wucha) * (r3 + r2 - wucha))) || ((d3 <= (Math.abs(r3 - r2) + wucha) * (Math.abs(r3 - r2) + wucha)) && (d3 >= (Math.abs(r3 - r2) - wucha) * (Math.abs(r3 - r2) - wucha)))) {
      dw.x = x3 + (x2 - x3) * (r3 / (r3 + r2))
      dw.y = y3 + (y2 - y3) * (r3 / (r3 + r2))
    }
    else {
      val ab = Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2))
      val ae = (r2 * r2 - r1 * r1 - ab * ab) / (-2 * ab)
      val ce = Math.sqrt(r1 * r1 - ae * ae)
      val E = new xy
      val C = new xy
      val D = new xy
      E.x = x1 + ((x2 - x1) * ae) / ab
      E.y = y1 + ((y2 - y1) * ae) / ab
      if (y2 - y1 == 0) {
        C.x = E.x
        C.y = E.y + ce
        D.x = E.x
        D.y = E.y - ce
      }
      else if (x2 - x1 == 0) {
        C.x = E.x + ce
        C.y = E.y
        D.x = E.x - ce
        D.y = E.y
      }
      else {
        val Kab = (y2 - y1) / (x2 - x1)
        val Kcd = (-1) / Kab
        val JCS = Math.atan(Kcd)
        C.x = E.x + ce * Math.cos(JCS)
        C.y = E.y + ce * Math.sin(JCS)
        D.x = E.x - ce * Math.cos(JCS)
        D.y = E.y - ce * Math.sin(JCS)
      }
      val dc3 = Math.sqrt((x3 - C.x) * (x3 - C.x) + (y3 - C.y) * (y3 - C.y))
      val dd3 = Math.sqrt((x3 - D.x) * (x3 - D.x) + (y3 - D.y) * (y3 - D.y))
      if (Math.abs(dd3 - r3) >= Math.abs(dc3 - r3)) {
        dw.x = C.x
        dw.y = C.y
      }
      else if (Math.abs(dd3 - r3) < Math.abs(dc3 - r3)) {
        dw.x = D.x
        dw.y = D.y
      }
    }
    dw
  }
}