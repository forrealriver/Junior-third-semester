/**
 * Created by hadoop on 17-5-22.
 */
public class Data {
    private String mac;
    private String rssi;
    private String range;
    public String getMac() {
        return mac;
    }
    public void setMac(String mac) {
        this.mac = mac;
    }
    public String getRssi() {
        return rssi;
    }
    public void setRssi(String rssi) {
        this.rssi = rssi;
    }
    public String getRange() {
        return range;
    }
    public void setRange(String range) {
        this.range = range;
    }
}
