package w.excption;

/**
 * Created by hadoop on 17-5-23.
 */
public class MatchFailedException extends Exception{

}
