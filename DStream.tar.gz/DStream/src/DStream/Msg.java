/**
 * Created by hadoop on 17-5-22.
 */

public class Msg {
    private String id;
    private String mmac;
    private String rate;
    private Data[] data;
    private String lon;
    private String lat;
    private String time;
    public String getMmac() {
        return mmac;
    }
    public void setMmac(String mmac) {
        this.mmac = mmac;
    }
    public String getRate() {
        return rate;
    }
    public void setRate(String rate) {
        this.rate = rate;
    }
    public Data[] getData() {
        return data;
    }
    public void setData(Data[] data) {
        this.data = data;
    }
    public String getLon() {
        return lon;
    }
    public void setLon(String lon) {
        this.lon = lon;
    }
    public String getLat() {
        return lat;
    }
    public void setLat(String lat) {
        this.lat = lat;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

}