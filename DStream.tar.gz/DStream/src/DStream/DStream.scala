/**
  * Created by hadoop on 17-5-21.
  */
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.hadoop.hbase._
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.SparkContext
import w.excption._
import  s.S
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.log4j.{Level,Logger}
object DStream {
  def main(array: Array[String]): Unit ={
    Logger.getLogger("org.apache.spark").setLevel(Level.ERROR)
    Logger.getLogger("org.eclipse.jetty.server").setLevel(Level.OFF)

    val conf = new SparkConf().setMaster("local[2]").setAppName("NetworkWordCountStateful").set("spark.driver.bindAddress", "10.6.72.52")
    conf.set("spark.testing.memory", "2147480000")
    val s=new SparkContext(conf)
    val sc = new StreamingContext(s, Seconds(3))
    sc.checkpoint("file:///usr/lib/spark/mycode/streaming/dstreamoutput/")
    val lines = sc.textFileStream("file:///home/hadoop/Desktop")
    val words = lines.flatMap(_.split(" "))
    val wordCounts = words.map(x => (x, 1)).reduceByKey(_ + _)
    wordCounts.print()

    wordCounts.foreachRDD(rdd => {
      def func(records: Iterator[(String,Int)]) {
        val conff = HBaseConfiguration.create()
        val conn = ConnectionFactory.createConnection(conff)
        val admin = conn.getAdmin
        val name = TableName.valueOf("wifi")
        val table = conn.getTable(name)
        records.foreach(data => {
          val p = new Put(Bytes.toBytes(data._1.trim))
          p.addColumn(Bytes.toBytes("info"), Bytes.toBytes("mac"), Bytes.toBytes(data._2.toInt))
          table.put(p)
        })
        conn.close()
      }
      val repartitionedRDD = rdd.repartition(3)
      repartitionedRDD.foreachPartition(func)

    })
    sc.start()
    sc.awaitTermination()
  }
}
