

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import w.excption.*;
public class Util {
    public static Msg WifiInfProcess(String context){
        JSONObject jo=JSONObject.fromObject(context);
        Msg msg=new Msg();
        msg.setLat(jo.getString("lat"));
        msg.setLon(jo.getString("lon"));
        msg.setMmac(jo.getString("mmac"));
        msg.setRate(jo.getString("rate"));
        msg.setTime(jo.getString("time"));
        msg.setId(jo.getString("id"));
        JSONArray ja=jo.getJSONArray("data");
        Data[] data=new Data[ja.size()];
        for(int i=0;i<=ja.size()-1;i++){
            JSONObject jo1=ja.getJSONObject(i);
            Data d=new Data();
            d.setMac(jo1.getString("mac"));
            d.setRange(jo1.getString("range"));
            d.setRssi(jo1.getString("rssi"));
            data[i]=d;
        }
        msg.setData(data);
        return msg;
    }


    /**
     * ���ڼ���ƥ���λ�ã���ͷ��β��
     * @param str
     * @param sub
     * @return
     */
    protected static int kmp(String str, String sub) {
        if(str == null || sub == null || str.length() == 0 || sub.length() == 0){
            throw new IllegalArgumentException("str����sub����Ϊ��");
        }
        int j = 0;
        int[] n = next(sub);
        for (int i = 0; i < str.length(); i++) {
            while(j > 0 && str.charAt(i) != sub.charAt(j)){
                j = n[j - 1];
            }

            if(str.charAt(i) == sub.charAt(j)){
                j++;
            }

            if(sub.length() == j){
                int index = i - j + 1;
                return index;
            }
        }

        return -1;
    }

    /**
     * �������ɲ���ƥ���
     * @param sub
     * @return
     */
    protected static int[] next(String sub) {
        int[] n = new int[sub.length()];
        int x = 0;
        for (int i = 1; i < sub.length(); i++) {
            while (x > 0 && sub.charAt(x) != sub.charAt(x)) {
                x = n[x - 1];
            }
            if (sub.charAt(i) == sub.charAt(x)) {
                x++;
            }
            n[i] = x;
        }
        return n;
    }
    /**
     * ��ȡ��data��ʼ��ʣ������
     * @param context
     * @return
     */
    public static String httphandle(String context) throws MatchFailedException{
        if(kmp(context, "data")==-1){
            throw new MatchFailedException();
        }
        return context.substring(kmp(context, "data")+5);
    }
}
