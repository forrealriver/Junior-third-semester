package s;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Created by hadoop on 17-5-23.
 */
public class S extends Thread{

    @Override
    public void run() {
        try{
            ServerSocket ss=new ServerSocket(9999);
            while(true) {
                Socket s = ss.accept();
            }
        } catch (IOException e){
            System.out.print("sshiba");
        }



    }
}
